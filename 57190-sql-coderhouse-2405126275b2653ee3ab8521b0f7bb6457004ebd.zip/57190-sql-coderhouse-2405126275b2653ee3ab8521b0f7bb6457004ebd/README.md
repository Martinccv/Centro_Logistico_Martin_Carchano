# 57190-sql-coderhouse
Curso destinado a generar conocimientos sobre la arquitectura básica de una base de datos Relacional en MySQL
- OS recomendado para la cursada: LINUX - WINDOWS -MACOS
- Editores de Codigo: MySQL Workbench | DBeaver | Adminer | VSC
- Servidores de Bases de datos : Containers Docker | MySQL Server Local | Base de datos Cloud

---
Se irá agregando material de clases dia a dia:
- keep the track
  

| Docente_ID | Nombre_Docente | Cargo          | Asignatura   | Alumno_ID | Nombre_Alumno | Fecha_Alta | Doc_ID_Facultad | Ciudad_Alumno | Nombre_Asignatura | Estado_Asignatura | Costo_Asignatura |
|------------|-----------------|----------------|--------------|-----------|---------------|------------|-----------------|---------------|-------------------|-------------------|------------------|
| 101        | Prof. García    | Profesor       | Matemáticas  | 201       | Juan Pérez    | 2023-01-15 | F123456         | Ciudad A      | Matemáticas       | Inscrita          | $500            |
| 102        | Prof. Martínez  | Profesor       | Historia     | 202       | María López   | 2023-02-20 | G789012         | Ciudad B      | Historia          | Aprobada          | $450            |
| 103        | Prof. Rodríguez | Profesor       | Informática  | 203       | Carlos Sánchez| 2023-03-10 | H345678         | Ciudad C      | Informática       | Pendiente         | $550            |
| 104        | Prof. López     | Profesor       | Física       | 204       | Laura Gómez   | 2023-04-05 | I901234         | Ciudad D      | Física            | Inscrita          | $480            |
| 105        | Prof. Ramírez   | Profesor       | Química      | 205       | Javier Ramírez| 2023-05-12 | J567890         | Ciudad E      | Química           | Aprobada          | $520            |
| 106        | Prof. Martínez  | Profesor       | Biología     | 206       | Ana Martínez  | 2023-06-08 | K123456         | Ciudad F      | Biología          | Inscrita          | $490            |
| 107        | Prof. Rodríguez | Profesor       | Literatura   | 207       | David Rodríguez| 2023-07-20 | L789012         | Ciudad G      | Literatura        | Pendiente         | $480            |
| 108        | Prof. Fernández | Profesor       | Artes        | 208       | Paula Fernández| 2023-08-15 | M345678         | Ciudad H      | Artes             | Aprobada          | $530            |
| 109        | Prof. Torres    | Profesor       | Economía     | 209       | Sergio Torres | 2023-09-02 | N901234         | Ciudad I      | Economía          | Inscrita          | $550            |
| 110        | Prof. Santos    | Profesor       | Historia     | 210       | Isabel Santos | 2023-10-10 | O567890         | Ciudad J      | Historia          | Aprobada          | $490            |

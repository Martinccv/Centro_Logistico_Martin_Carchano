USE my_database_change_me;

-- Trigger para almacenar registros modificados si la reserva se cancela:

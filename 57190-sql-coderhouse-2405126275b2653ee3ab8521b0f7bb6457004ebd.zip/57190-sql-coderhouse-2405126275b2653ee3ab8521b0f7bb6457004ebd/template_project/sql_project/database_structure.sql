DROP DATABASE IF EXISTS my_database_change_me;
CREATE DATABASE my_database_change_me;
USE my_database_change_me;

-- TABLAS DIMENSIONALES
-- Tabla CLIENTE
